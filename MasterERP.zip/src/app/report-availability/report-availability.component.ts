import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-availability',
  templateUrl: './report-availability.component.html',
  styleUrls: ['./report-availability.component.css']
})
export class ReportAvailabilityComponent implements OnInit {

  constructor() {
    console.log('I am in ReportAvailabilityComponent');
  }

  ngOnInit() {
  }
}
