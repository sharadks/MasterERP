import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-dictionary',
  templateUrl: './data-dictionary.component.html',
  styleUrls: ['./data-dictionary.component.css']
})
export class DataDictionaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
