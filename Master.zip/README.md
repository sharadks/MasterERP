1. npm install

2. npm install -g @angular/cli

3. ng serve // Local run

4. ng build // you will get dist folder then deploy accordingly

5. localhost:8000