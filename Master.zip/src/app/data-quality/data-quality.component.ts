import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-quality',
  templateUrl: './data-quality.component.html',
  styleUrls: ['./data-quality.component.css']
})
export class DataQualityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
