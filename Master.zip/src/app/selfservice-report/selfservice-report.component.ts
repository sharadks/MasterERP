import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selfservice-report',
  templateUrl: './selfservice-report.component.html',
  styleUrls: ['./selfservice-report.component.css']
})
export class SelfserviceReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
